/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package svgdraw;

/**
 *
 * @author Tobias
 */
public class SVGDraw
{
    public static void main(String[] args)
    {
        System.out.println(drawGrid(2,3,200,300,8));
    }
    public static String drawGrid(int columns, int rows, int width, int height, int strokeWidth)
    {   
        int sizeX = (width-1) / columns;
        int sizeY = (height-1) / rows;
        width = sizeX * columns;
        height = sizeY * rows;
        StringBuilder res = new StringBuilder();
        
        //Begin svg tag
        res.append("<svg width=\"").append(width).append("\" height=\"").append(height).append("\">\n");
        
        
        //Vertical lines
        for(int y = 0; y <= height; y += sizeY)
        {
            //<line x1="0" y1="0" x2="200" y2="200" style="stroke:rgb(0,0,0);stroke-width:1" />
            res.append("<line x1=\"0\" y1=\"").append(y).append("\" x2=\"").append(width-1)
                    .append("\" y2=\"").append(y).append("\" style=\"stroke:rgb(0,0,0);stroke-width:").append(strokeWidth).append("\" />\n");
        }
        
        //Horizontal lines
        for(int x = 0; x <= width; x += sizeX)
        {
            //<line x1="0" y1="0" x2="200" y2="200" style="stroke:rgb(0,0,0);stroke-width:1" />
            res.append("<line x1=\"").append(x).append("\" y1=\"0\" x2=\"").append(x)
                    .append("\" y2=\"").append(height-1).append("\" style=\"stroke:rgb(0,0,0);stroke-width:").append(strokeWidth).append("\" />\n");
        }
        
        //End svg tag
        res.append("</svg>");
        
        return res.toString();
    }
}
